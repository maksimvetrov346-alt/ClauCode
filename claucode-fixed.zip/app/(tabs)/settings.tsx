import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { SchemeColors, type ColorScheme } from "@/constants/theme";
import { useColors } from "@/hooks/use-colors";
import { useThemeContext } from "@/lib/theme-provider";

export default function SettingsScreen() {
  const colors = useColors();
  const { colorScheme, setColorScheme } = useThemeContext();
  const themes: Array<{ id: ColorScheme; title: string; caption: string; icon: "dark-mode" | "light-mode" }> = [
    { id: "dark", title: "Ember dark", caption: "Угольный фон · оранжевый сигнал", icon: "dark-mode" },
    { id: "light", title: "Warm light", caption: "Тёплая поверхность · спокойный контраст", icon: "light-mode" },
  ];
  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={[styles.eyebrow, { color: colors.tint }]}>CONTROL ROOM</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Настройки</Text>
        <Text style={[styles.subtitle, { color: colors.muted }]}>Тема и поведение рабочей среды ClauCode.</Text>

        <Text style={[styles.sectionLabel, { color: colors.muted }]}>ТЕМА</Text>
        <View style={styles.themeList}>
          {themes.map((theme) => {
            const active = colorScheme === theme.id;
            return <Pressable key={theme.id} onPress={() => setColorScheme(theme.id)} style={({ pressed }) => [styles.themeCard, { backgroundColor: active ? SchemeColors[theme.id].surface : colors.surface, borderColor: active ? colors.tint : colors.border, opacity: pressed ? 0.75 : 1 }]}>
              <View style={[styles.themeIcon, { backgroundColor: active ? colors.tint : colors.background }]}><MaterialIcons name={theme.icon} size={21} color={active ? "#FFF8F0" : colors.foreground} /></View>
              <View style={styles.themeCopy}><Text style={[styles.themeTitle, { color: colors.foreground }]}>{theme.title}</Text><Text style={[styles.themeCaption, { color: colors.muted }]}>{theme.caption}</Text></View>
              {active && <MaterialIcons name="check-circle" size={21} color={colors.tint} />}
            </Pressable>;
          })}
        </View>

        <Text style={[styles.sectionLabel, { color: colors.muted }]}>О ПРИЛОЖЕНИИ</Text>
        <View style={[styles.aboutCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.aboutRow}><Text style={[styles.aboutLabel, { color: colors.muted }]}>Версия</Text><Text style={[styles.aboutValue, { color: colors.foreground }]}>0.1.0 MVP</Text></View>
          <View style={styles.aboutRow}><Text style={[styles.aboutLabel, { color: colors.muted }]}>Рабочее пространство</Text><Text style={[styles.aboutValue, { color: colors.foreground }]}>claucode-app</Text></View>
          <View style={styles.aboutRow}><Text style={[styles.aboutLabel, { color: colors.muted }]}>AI runtime</Text><View style={styles.runtime}><View style={[styles.runtimeDot, { backgroundColor: colors.success }]} /><Text style={[styles.aboutValue, { color: colors.success }]}>ready</Text></View></View>
        </View>

        <View style={[styles.note, { borderColor: colors.border }]}><MaterialIcons name="construction" size={19} color={colors.tint} /><Text style={[styles.noteText, { color: colors.muted }]}>Сборка APK, файловый sandbox и генераторы 2D/3D будут следующими модулями поверх этой основы.</Text></View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 18, paddingTop: 18, paddingBottom: 28, gap: 14 },
  eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 1.5 },
  title: { fontSize: 30, fontWeight: "800", letterSpacing: -0.8, marginTop: -2 },
  subtitle: { fontSize: 14, lineHeight: 20 },
  sectionLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 1.4, marginTop: 6 },
  themeList: { gap: 9 },
  themeCard: { borderWidth: 1, borderRadius: 16, padding: 12, flexDirection: "row", alignItems: "center", gap: 11 },
  themeIcon: { width: 41, height: 41, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  themeCopy: { flex: 1, gap: 3 },
  themeTitle: { fontSize: 14, fontWeight: "700" },
  themeCaption: { fontSize: 11 },
  aboutCard: { borderWidth: 1, borderRadius: 16, paddingHorizontal: 14 },
  aboutRow: { minHeight: 45, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: "rgba(128,128,128,0.17)", flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  aboutLabel: { fontSize: 12 },
  aboutValue: { fontSize: 12, fontWeight: "700", fontFamily: "monospace" },
  runtime: { flexDirection: "row", alignItems: "center", gap: 5 },
  runtimeDot: { width: 7, height: 7, borderRadius: 4 },
  note: { borderWidth: 1, borderRadius: 14, padding: 13, flexDirection: "row", gap: 9, alignItems: "flex-start", marginTop: 4 },
  noteText: { flex: 1, fontSize: 11, lineHeight: 17 },
});

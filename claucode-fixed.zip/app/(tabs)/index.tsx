import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useMemo, useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { QUICK_PROMPTS, STARTER_MESSAGES, type ChatMessage } from "@/lib/claucode";
import { trpc } from "@/lib/trpc";

const makeId = () => `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

function BrandMark() {
  const colors = useColors();
  return <View style={styles.brandRow}><View style={[styles.brandDot, { backgroundColor: colors.tint }]} /><Text style={[styles.brandText, { color: colors.foreground }]}>ClauCode</Text></View>;
}

function MessageBubble({ message }: { message: ChatMessage }) {
  const colors = useColors();
  const isUser = message.role === "user";
  return <View style={[styles.messageRow, isUser && styles.messageRowUser]}>
    {!isUser && <View style={[styles.avatar, { backgroundColor: colors.tint }]}><Text style={styles.avatarText}>C</Text></View>}
    <View style={[styles.messageBubble, { backgroundColor: isUser ? colors.tint : colors.surface, borderColor: isUser ? colors.tint : colors.border }, isUser ? styles.userBubble : styles.assistantBubble]}>
      <Text style={[styles.messageText, { color: isUser ? "#FFF8F0" : colors.foreground }]}>{message.content}</Text>
      {message.time && <Text style={[styles.messageTime, { color: isUser ? "#FFD7BC" : colors.muted }]}>{message.time}</Text>}
    </View>
  </View>;
}

export default function HomeScreen() {
  const colors = useColors();
  const [messages, setMessages] = useState<ChatMessage[]>(STARTER_MESSAGES);
  const [draft, setDraft] = useState("");
  const [isThinking, setIsThinking] = useState(false);
  const chatMutation = trpc.assistant.chat.useMutation();
  const visiblePrompts = useMemo(() => QUICK_PROMPTS.slice(0, 3), []);

  const sendMessage = async (value = draft) => {
    const content = value.trim();
    if (!content || isThinking) return;
    const nextUser: ChatMessage = { id: makeId(), role: "user", content, time: "сейчас" };
    const nextHistory = [...messages, nextUser];
    setMessages(nextHistory); setDraft(""); setIsThinking(true);
    try {
      const result = await chatMutation.mutateAsync({ projectName: "claucode-app", messages: nextHistory.map(({ role, content: text }) => ({ role, content: text })) });
      setMessages((current) => [...current, { id: makeId(), role: "assistant", content: result.reply, time: "только что" }]);
    } catch (error) {
      setMessages((current) => [...current, { id: makeId(), role: "assistant", content: error instanceof Error ? `Не получилось выполнить запрос: ${error.message}` : "Не получилось выполнить запрос. Попробуй ещё раз.", time: "ошибка" }]);
    } finally { setIsThinking(false); }
  };

  return <ScreenContainer edges={["top", "left", "right"]}>
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <BrandMark />
        <View style={styles.headerActions}><View style={[styles.onlineDot, { backgroundColor: colors.success }]} /><Text style={[styles.headerCaption, { color: colors.muted }]}>готов к работе</Text><Pressable style={styles.headerButton} onPress={() => setMessages(STARTER_MESSAGES)}><MaterialIcons name="add-comment" size={21} color={colors.foreground} /></Pressable></View>
      </View>
      <ScrollView style={styles.flex} contentContainerStyle={styles.chatContent} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <View style={styles.contextLine}><Text style={[styles.contextLabel, { color: colors.muted }]}>WORKSPACE</Text><Text style={[styles.contextValue, { color: colors.foreground }]}>claucode-app</Text><MaterialIcons name="chevron-right" size={16} color={colors.muted} /><Text style={[styles.contextValue, { color: colors.tint }]}>main</Text></View>
        <View style={styles.introBlock}><Text style={[styles.eyebrow, { color: colors.tint }]}>COMMAND CENTER</Text><Text style={[styles.title, { color: colors.foreground }]}>Что собираем сегодня?</Text><Text style={[styles.subtitle, { color: colors.muted }]}>Опиши результат. Я превращу идею в понятный план и подключу нужные инструменты.</Text></View>
        {messages.map((message) => <MessageBubble key={message.id} message={message} />)}
        {messages.length === 1 && <View style={styles.quickBlock}><Text style={[styles.sectionLabel, { color: colors.muted }]}>БЫСТРЫЙ СТАРТ</Text><View style={styles.quickGrid}>{visiblePrompts.map((item) => <Pressable key={item.label} onPress={() => sendMessage(item.prompt)} style={({ pressed }) => [styles.quickCard, { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.72 : 1 }]}><Text style={[styles.quickLabel, { color: colors.foreground }]}>{item.label}</Text><MaterialIcons name="arrow-outward" size={18} color={colors.tint} /></Pressable>)}</View></View>}
        {isThinking && <View style={styles.thinkingRow}><View style={[styles.avatar, { backgroundColor: colors.tint }]}><Text style={styles.avatarText}>C</Text></View><View style={[styles.thinkingBubble, { backgroundColor: colors.surface, borderColor: colors.border }]}><ActivityIndicator size="small" color={colors.tint} /><Text style={[styles.thinkingText, { color: colors.muted }]}>ClauCode думает…</Text></View></View>}
      </ScrollView>
      <View style={[styles.composerWrap, { borderTopColor: colors.border, backgroundColor: colors.background }]}><View style={[styles.composer, { backgroundColor: colors.surface, borderColor: colors.border }]}><TextInput value={draft} onChangeText={setDraft} placeholder="Опиши задачу для ClauCode…" placeholderTextColor={colors.muted} multiline maxLength={12000} style={[styles.input, { color: colors.foreground }]} returnKeyType="default" /><Pressable accessibilityLabel="Отправить задачу" disabled={!draft.trim() || isThinking} onPress={() => sendMessage()} style={({ pressed }) => [styles.sendButton, { backgroundColor: draft.trim() && !isThinking ? colors.tint : colors.border, opacity: pressed ? 0.76 : 1 }]}><MaterialIcons name="arrow-upward" size={21} color={draft.trim() && !isThinking ? "#FFF8F0" : colors.muted} /></Pressable></View><Text style={[styles.composerHint, { color: colors.muted }]}>ClauCode может ошибаться. Проверяй команды и подключённые сервисы.</Text></View>
    </KeyboardAvoidingView>
  </ScreenContainer>;
}

const styles = StyleSheet.create({
  flex: { flex: 1 }, header: { minHeight: 62, paddingHorizontal: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: StyleSheet.hairlineWidth }, brandRow: { flexDirection: "row", alignItems: "center", gap: 8 }, brandDot: { width: 9, height: 9, borderRadius: 5 }, brandText: { fontSize: 19, fontWeight: "800", letterSpacing: -0.5 }, headerActions: { flexDirection: "row", alignItems: "center", gap: 6 }, onlineDot: { width: 7, height: 7, borderRadius: 4, marginRight: 2 }, headerCaption: { fontSize: 11, fontWeight: "600" }, headerButton: { marginLeft: 9, padding: 4 }, chatContent: { paddingHorizontal: 18, paddingTop: 16, paddingBottom: 24, gap: 15 }, contextLine: { flexDirection: "row", alignItems: "center", gap: 7 }, contextLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 1.2 }, contextValue: { fontSize: 12, fontFamily: "monospace", fontWeight: "600" }, introBlock: { gap: 6, marginTop: 4, marginBottom: 5 }, eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 1.6 }, title: { fontSize: 28, lineHeight: 33, fontWeight: "800", letterSpacing: -0.8 }, subtitle: { fontSize: 14, lineHeight: 20, maxWidth: 360 }, messageRow: { flexDirection: "row", alignItems: "flex-start", gap: 9, maxWidth: 600 }, messageRowUser: { justifyContent: "flex-end", alignSelf: "stretch" }, avatar: { width: 26, height: 26, borderRadius: 8, alignItems: "center", justifyContent: "center", marginTop: 2 }, avatarText: { color: "#FFF8F0", fontSize: 14, fontWeight: "800" }, messageBubble: { borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, paddingTop: 11, paddingBottom: 9, maxWidth: "86%" }, assistantBubble: { borderTopLeftRadius: 5 }, userBubble: { borderTopRightRadius: 5 }, messageText: { fontSize: 15, lineHeight: 22 }, messageTime: { fontSize: 10, marginTop: 7, alignSelf: "flex-end" }, quickBlock: { gap: 9, marginTop: 3 }, sectionLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 1.4 }, quickGrid: { flexDirection: "row", flexWrap: "wrap", gap: 9 }, quickCard: { minHeight: 50, flexGrow: 1, flexBasis: "30%", borderWidth: 1, borderRadius: 13, paddingHorizontal: 12, paddingVertical: 10, flexDirection: "row", justifyContent: "space-between", alignItems: "center" }, quickLabel: { fontSize: 13, fontWeight: "700", flexShrink: 1 }, thinkingRow: { flexDirection: "row", alignItems: "center", gap: 9 }, thinkingBubble: { flexDirection: "row", alignItems: "center", gap: 9, borderWidth: 1, borderRadius: 14, paddingHorizontal: 13, paddingVertical: 10 }, thinkingText: { fontSize: 13 }, composerWrap: { borderTopWidth: 1, paddingHorizontal: 14, paddingTop: 10, paddingBottom: 5 }, composer: { minHeight: 58, maxHeight: 150, borderWidth: 1, borderRadius: 17, paddingLeft: 14, paddingRight: 7, paddingVertical: 7, flexDirection: "row", alignItems: "flex-end" }, input: { flex: 1, fontSize: 15, lineHeight: 21, paddingTop: 6, paddingBottom: 6, paddingRight: 8, minHeight: 40 }, sendButton: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" }, composerHint: { fontSize: 10, textAlign: "center", paddingVertical: 5 },
});

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as Clipboard from "expo-clipboard";
import { useMemo, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { getApiBaseUrl } from "@/constants/oauth";

export default function McpScreen() {
  const colors = useColors();
  const [copied, setCopied] = useState(false);
  const connectorUrl = useMemo(() => `${getApiBaseUrl()}/mcp`, []);

  const copyConnectorUrl = async () => {
    await Clipboard.setStringAsync(connectorUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <Text style={[styles.eyebrow, { color: colors.tint }]}>CLAUDE CONNECTOR</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Ссылка ClauCode</Text>
        <Text style={[styles.subtitle, { color: colors.muted }]}>Скопируй эту ссылку и вставь её в Claude → Settings → Connectors → Add custom connector.</Text>

        <View style={[styles.form, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.inputLabelRow}><Text style={[styles.inputLabel, { color: colors.foreground }]}>Твой MCP endpoint</Text><View style={styles.readyPill}><View style={[styles.readyDot, { backgroundColor: colors.success }]} /><Text style={[styles.required, { color: colors.success }]}>READY</Text></View></View>
          <View style={[styles.urlBox, { backgroundColor: colors.background, borderColor: colors.border }]}><Text selectable style={[styles.url, { color: colors.foreground }]}>{connectorUrl}</Text></View>
          <Pressable onPress={copyConnectorUrl} style={({ pressed }) => [styles.connectButton, { backgroundColor: copied ? colors.success : colors.tint, opacity: pressed ? 0.78 : 1 }]}>
            <MaterialIcons name={copied ? "check" : "content-copy"} size={19} color="#FFF8F0" />
            <Text style={styles.connectText}>{copied ? "Ссылка скопирована" : "Копировать ссылку"}</Text>
          </Pressable>
          <Text style={[styles.formHint, { color: colors.muted }]}>Endpoint работает по MCP Streamable HTTP и отдаёт инструменты ClauCode.</Text>
        </View>

        <Text style={[styles.sectionLabel, { color: colors.muted }]}>КАК ПОДКЛЮЧИТЬ</Text>
        <View style={styles.steps}>
          {["Нажми «Копировать ссылку» выше.", "Открой Claude и зайди в Settings → Connectors.", "Выбери Add custom connector, вставь ссылку и сохрани.", "После подключения Claude увидит claucode_chat и claucode_project_status."].map((step, index) => <View key={step} style={[styles.step, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={[styles.stepNumber, { backgroundColor: index === 0 ? colors.tint : colors.background }]}><Text style={[styles.stepNumberText, { color: index === 0 ? "#FFF8F0" : colors.foreground }]}>{index + 1}</Text></View><Text style={[styles.stepText, { color: colors.foreground }]}>{step}</Text></View>)}
        </View>

        <View style={[styles.toolCard, { backgroundColor: colors.surface, borderColor: colors.border }]}><MaterialIcons name="hub" size={21} color={colors.tint} /><View style={styles.toolCopy}><Text style={[styles.toolTitle, { color: colors.foreground }]}>ClauCode MCP Server · CONNECTED</Text><Text style={[styles.toolText, { color: colors.muted }]}>После подключения Claude сможет отправлять задачи в ClauCode через MCP.</Text></View></View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 18, paddingTop: 18, paddingBottom: 28, gap: 14 },
  eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 1.5 },
  title: { fontSize: 30, fontWeight: "800", letterSpacing: -0.8, marginTop: -2 },
  subtitle: { fontSize: 14, lineHeight: 20, maxWidth: 370 },
  form: { borderWidth: 1, borderRadius: 17, padding: 13, gap: 9, marginTop: 4 },
  inputLabelRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  inputLabel: { fontSize: 13, fontWeight: "700" },
  required: { fontSize: 10, fontWeight: "800", letterSpacing: 1 },
  readyPill: { flexDirection: "row", alignItems: "center", gap: 5 },
  readyDot: { width: 7, height: 7, borderRadius: 4 },
  urlBox: { minHeight: 54, borderWidth: 1, borderRadius: 11, paddingHorizontal: 12, paddingVertical: 11, justifyContent: "center" },
  url: { fontSize: 12, fontFamily: "monospace", lineHeight: 18 },
  connectButton: { height: 46, borderRadius: 12, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  connectText: { fontSize: 14, fontWeight: "800", color: "#FFF8F0" },
  formHint: { fontSize: 10, lineHeight: 15, textAlign: "center", paddingHorizontal: 6 },
  sectionLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 1.4, marginTop: 4 },
  steps: { gap: 8 },
  step: { borderWidth: 1, borderRadius: 14, padding: 11, flexDirection: "row", alignItems: "center", gap: 10 },
  stepNumber: { width: 27, height: 27, borderRadius: 9, alignItems: "center", justifyContent: "center" },
  stepNumberText: { fontSize: 12, fontWeight: "900" },
  stepText: { flex: 1, fontSize: 12, lineHeight: 17 },
  toolCard: { borderWidth: 1, borderRadius: 15, padding: 13, flexDirection: "row", gap: 10, alignItems: "flex-start", marginTop: 3 },
  toolCopy: { flex: 1, gap: 4 },
  toolTitle: { fontSize: 12, fontWeight: "800" },
  toolText: { fontSize: 11, lineHeight: 16 },
});

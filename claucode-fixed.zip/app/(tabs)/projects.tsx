import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { ActivityIndicator, Alert, Linking, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

export default function ProjectsScreen() {
  const colors = useColors();
  const status = trpc.workspace.status.useQuery(undefined, { refetchOnMount: "always" });
  const createProject = trpc.workspace.createProject.useMutation({ onSuccess: () => status.refetch() });
  const check = trpc.workspace.runCheck.useMutation();
  const build = trpc.workspace.buildApk.useMutation();
  const [selected, setSelected] = useState<string>();
  const files = trpc.workspace.files.useQuery({ project: selected || "__none__" }, { enabled: Boolean(selected) });
  const projects = status.data?.projects || [];

  const create = async () => {
    const name = `project-${Date.now().toString().slice(-6)}`;
    try { await createProject.mutateAsync({ name, type: "html" }); setSelected(name); Alert.alert("Проект создан", `${name} сохранён на сервере.`); }
    catch (error) { Alert.alert("Не удалось создать проект", error instanceof Error ? error.message : "Неизвестная ошибка"); }
  };
  const runCheck = async (project: string) => {
    try { const result = await check.mutateAsync({ project }); Alert.alert(result.ok ? "Проверка пройдена" : "Есть ошибки", result.log); }
    catch (error) { Alert.alert("Ошибка проверки", error instanceof Error ? error.message : "Неизвестная ошибка"); }
  };
  const buildApk = async (project: string) => {
    try {
      const result = await build.mutateAsync({ project, appName: project, packageId: `com.claucode.${project.replace(/[^a-zA-Z0-9]/g, "").toLowerCase()}` });
      const apkPath = (result as { apkPath?: string }).apkPath;
      if (result.ok && apkPath) { Alert.alert("APK готов", result.log, [{ text: "Скачать", onPress: () => Linking.openURL(apkPath) }, { text: "Закрыть" }]); }
      else Alert.alert("APK не собран", result.error || result.log);
    } catch (error) { Alert.alert("Ошибка сборки", error instanceof Error ? error.message : "Неизвестная ошибка"); }
  };

  return <ScreenContainer>
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      <View style={styles.topRow}><View><Text style={[styles.eyebrow, { color: colors.tint }]}>WORKSPACES</Text><Text style={[styles.title, { color: colors.foreground }]}>Проекты</Text></View><Pressable onPress={create} disabled={createProject.isPending} style={[styles.addButton, { backgroundColor: colors.tint }]}><MaterialIcons name="add" color="#FFF8F0" size={22} /></Pressable></View>
      <Text style={[styles.subtitle, { color: colors.muted }]}>Файлы сохраняются на сервере. AI может создавать и менять их через инструменты.</Text>
      <View style={styles.statsRow}><View style={[styles.stat, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.statValue, { color: colors.foreground }]}>{String(projects.length).padStart(2, "0")}</Text><Text style={[styles.statLabel, { color: colors.muted }]}>пространства</Text></View><View style={[styles.stat, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.statValue, { color: colors.foreground }]}>{status.data?.android?.sdk ? "ON" : "OFF"}</Text><Text style={[styles.statLabel, { color: colors.muted }]}>Android worker</Text></View></View>
      {status.isLoading && <ActivityIndicator color={colors.tint} />}
      <Text style={[styles.sectionLabel, { color: colors.muted }]}>СЕРВЕРНЫЕ ПРОЕКТЫ</Text>
      <View style={styles.projectList}>{projects.map((project, index) => <View key={project.name} style={[styles.projectCard, { backgroundColor: colors.surface, borderColor: selected === project.name ? colors.tint : colors.border }]}>
        <Pressable onPress={() => setSelected(selected === project.name ? undefined : project.name)} style={styles.projectMain}><View style={[styles.projectIcon, { backgroundColor: index === 0 ? colors.tint : colors.background }]}><MaterialIcons name={project.type === "html" || project.type === "android-web" ? "language" : "folder"} size={22} color={index === 0 ? "#FFF8F0" : colors.foreground} /></View><View style={styles.projectCopy}><Text style={[styles.projectTitle, { color: colors.foreground }]}>{project.name}</Text><Text style={[styles.projectMeta, { color: colors.muted }]}>{project.type} · {project.files} файлов</Text></View><MaterialIcons name={selected === project.name ? "expand-less" : "expand-more"} size={20} color={colors.muted} /></Pressable>
        {selected === project.name && <View style={styles.details}><Text style={[styles.filesTitle, { color: colors.foreground }]}>ФАЙЛЫ</Text>{files.isLoading ? <ActivityIndicator color={colors.tint} /> : files.data?.map((file) => <Text key={file.path} style={[styles.file, { color: colors.muted }]} numberOfLines={1}>↳ {file.path} · {file.bytes} B</Text>)}<View style={styles.actions}><Pressable onPress={() => runCheck(project.name)} style={[styles.action, { borderColor: colors.border }]}><MaterialIcons name="fact-check" size={16} color={colors.tint} /><Text style={[styles.actionText, { color: colors.foreground }]}>Проверить</Text></Pressable><Pressable onPress={() => buildApk(project.name)} style={[styles.action, { backgroundColor: colors.tint, borderColor: colors.tint }]}><MaterialIcons name="build" size={16} color="#FFF8F0" /><Text style={[styles.actionText, { color: "#FFF8F0" }]}>Собрать APK</Text></Pressable></View></View>}
      </View>)}</View>
      {!status.isLoading && !projects.length && <View style={[styles.empty, { backgroundColor: colors.surface, borderColor: colors.border }]}><Text style={[styles.emptyTitle, { color: colors.foreground }]}>Пока нет проектов</Text><Text style={[styles.projectMeta, { color: colors.muted }]}>Нажми + или попроси AI создать рабочее пространство.</Text></View>}
      <View style={[styles.callout, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={[styles.calloutMark, { backgroundColor: colors.tint }]} /><View style={styles.calloutCopy}><Text style={[styles.calloutTitle, { color: colors.foreground }]}>Честный build status</Text><Text style={[styles.calloutText, { color: colors.muted }]}>{status.data?.android?.sdk ? "Android toolchain обнаружен." : "Android SDK/Gradle worker пока не подключён: приложение покажет причину, а не фальшивую ссылку."}</Text></View></View>
    </ScrollView>
  </ScreenContainer>;
}

const styles = StyleSheet.create({ content: { paddingHorizontal: 18, paddingTop: 18, paddingBottom: 28, gap: 15 }, topRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" }, eyebrow: { fontSize: 10, fontWeight: "800", letterSpacing: 1.6, marginBottom: 6 }, title: { fontSize: 30, fontWeight: "800", letterSpacing: -0.8 }, subtitle: { fontSize: 14, lineHeight: 20 }, addButton: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" }, statsRow: { flexDirection: "row", gap: 10, marginTop: 4 }, stat: { flex: 1, borderWidth: 1, borderRadius: 15, padding: 13 }, statValue: { fontSize: 24, fontWeight: "800" }, statLabel: { fontSize: 11, marginTop: 2 }, sectionLabel: { fontSize: 10, fontWeight: "800", letterSpacing: 1.4, marginTop: 5 }, projectList: { gap: 9 }, projectCard: { borderWidth: 1, borderRadius: 16, overflow: "hidden" }, projectMain: { minHeight: 72, padding: 12, flexDirection: "row", alignItems: "center", gap: 12 }, projectIcon: { width: 43, height: 43, borderRadius: 13, alignItems: "center", justifyContent: "center" }, projectCopy: { flex: 1, gap: 4 }, projectTitle: { fontSize: 15, fontWeight: "700" }, projectMeta: { fontSize: 12 }, details: { padding: 12, paddingTop: 0, gap: 5 }, filesTitle: { fontSize: 10, fontWeight: "800", letterSpacing: 1.2, marginTop: 2 }, file: { fontFamily: "monospace", fontSize: 11 }, actions: { flexDirection: "row", gap: 8, marginTop: 8 }, action: { flex: 1, minHeight: 38, borderWidth: 1, borderRadius: 11, flexDirection: "row", gap: 6, alignItems: "center", justifyContent: "center" }, actionText: { fontSize: 12, fontWeight: "700" }, empty: { borderWidth: 1, borderRadius: 16, padding: 16, gap: 5 }, emptyTitle: { fontSize: 15, fontWeight: "700" }, callout: { borderWidth: 1, borderRadius: 16, padding: 14, flexDirection: "row", gap: 11, marginTop: 5 }, calloutMark: { width: 4, borderRadius: 3 }, calloutCopy: { flex: 1, gap: 4 }, calloutTitle: { fontSize: 14, fontWeight: "700" }, calloutText: { fontSize: 12, lineHeight: 18 },
});

import type { Express, Request, Response } from "express";
import { invokeLLM } from "./llm";
import { buildApk, createProject, deleteFile, editFile, getBuildStatus, listFiles, projectStatus, readFile, runCheck, writeFile } from "./projectManager";

type JsonRpcRequest = { jsonrpc?: string; id?: string | number | null; method?: string; params?: Record<string, unknown> };
const jsonRpc = (id: JsonRpcRequest["id"], result: unknown) => ({ jsonrpc: "2.0", id: id ?? null, result });
const jsonRpcError = (id: JsonRpcRequest["id"], code: number, message: string) => ({ jsonrpc: "2.0", id: id ?? null, error: { code, message } });
const textResult = (value: unknown, isError = false) => ({ content: [{ type: "text", text: typeof value === "string" ? value : JSON.stringify(value, null, 2) }], ...(isError ? { isError: true } : {}) });
const stringProperty = (description: string) => ({ type: "string", description });

const tools = [
  { name: "create_project", description: "Create a persistent ClauCode workspace project.", inputSchema: { type: "object", properties: { name: stringProperty("Project name"), type: { type: "string", enum: ["html", "love2d", "godot", "android-web"] } }, required: ["name", "type"], additionalProperties: false } },
  { name: "write_file", description: "Write a complete UTF-8 file into a project. Parent directories are created automatically.", inputSchema: { type: "object", properties: { project: stringProperty("Project name"), path: stringProperty("Relative file path"), content: stringProperty("Complete file content") }, required: ["project", "path", "content"], additionalProperties: false } },
  { name: "edit_file", description: "Replace exactly one occurrence in a project file.", inputSchema: { type: "object", properties: { project: stringProperty("Project name"), path: stringProperty("Relative file path"), old: stringProperty("Exact old text"), new: stringProperty("Replacement text") }, required: ["project", "path", "old", "new"], additionalProperties: false } },
  { name: "read_file", description: "Read a UTF-8 project file.", inputSchema: { type: "object", properties: { project: stringProperty("Project name"), path: stringProperty("Relative file path") }, required: ["project", "path"], additionalProperties: false } },
  { name: "list_files", description: "List all files in a project.", inputSchema: { type: "object", properties: { project: stringProperty("Project name") }, required: ["project"], additionalProperties: false } },
  { name: "delete_file", description: "Delete one project file.", inputSchema: { type: "object", properties: { project: stringProperty("Project name"), path: stringProperty("Relative file path") }, required: ["project", "path"], additionalProperties: false } },
  { name: "run_check", description: "Run syntax and basic HTML/JSON checks and return a complete log.", inputSchema: { type: "object", properties: { project: stringProperty("Project name") }, required: ["project"], additionalProperties: false } },
  { name: "build_apk", description: "Build a signed APK through the configured Android build worker. Never returns a fake URL.", inputSchema: { type: "object", properties: { project: stringProperty("Project name"), app_name: stringProperty("App display name"), package_id: stringProperty("Android package ID"), icon: stringProperty("Optional relative icon path") }, required: ["project", "app_name", "package_id"], additionalProperties: false } },
  { name: "get_build_status", description: "Get persistent build status and complete log by build ID.", inputSchema: { type: "object", properties: { build_id: stringProperty("Build ID") }, required: ["build_id"], additionalProperties: false } },
  { name: "project_status", description: "List projects, server capabilities, storage path and Android toolchain status.", inputSchema: { type: "object", properties: {}, additionalProperties: false } },
  { name: "claucode_chat", description: "Ask ClauCode AI for practical help. It never claims actions that were not executed.", inputSchema: { type: "object", properties: { task: stringProperty("Task") }, required: ["task"], additionalProperties: false } },
];

async function callTool(name: string, args: Record<string, unknown> = {}) {
  switch (name) {
    case "create_project": return createProject(String(args.name || ""), args.type as "html" | "love2d" | "godot" | "android-web").then(textResult);
    case "write_file": return writeFile(String(args.project || ""), String(args.path || ""), String(args.content ?? "")).then(textResult);
    case "edit_file": return editFile(String(args.project || ""), String(args.path || ""), String(args.old ?? ""), String(args.new ?? "")).then(textResult);
    case "read_file": return readFile(String(args.project || ""), String(args.path || "")).then(textResult);
    case "list_files": return listFiles(String(args.project || "")).then(textResult);
    case "delete_file": return deleteFile(String(args.project || ""), String(args.path || "")).then(textResult);
    case "run_check": return runCheck(String(args.project || "")).then(textResult);
    case "build_apk": return buildApk(String(args.project || ""), String(args.app_name || ""), String(args.package_id || ""), typeof args.icon === "string" ? args.icon : undefined).then(textResult);
    case "get_build_status": return getBuildStatus(String(args.build_id || "")).then(textResult);
    case "project_status": return projectStatus().then(textResult);
    case "claucode_chat": {
      const task = String(args.task || "").trim();
      if (!task) throw new Error("task is required");
      const result = await invokeLLM({ messages: [
        { role: "system", content: "You are ClauCode connected through MCP. Answer in the user's language, be practical and occasionally witty. Do not claim that files, checks or builds happened unless a workspace tool result proves it." },
        { role: "user", content: task },
      ], maxTokens: 1400 });
      const content = result.choices?.[0]?.message?.content;
      return textResult(typeof content === "string" ? content : "ClauCode не вернул текстовый ответ.");
    }
    default: throw new Error(`Unknown tool: ${name}`);
  }
}

export function registerMcpRoutes(app: Express) {
  app.get("/mcp", (_req: Request, res: Response) => res.json({ name: "ClauCode", protocol: "MCP", transport: "streamable-http", status: "ready", tools: tools.map((tool) => tool.name) }));
  app.post("/mcp", async (req: Request, res: Response) => {
    const body = req.body as JsonRpcRequest;
    const id = body?.id;
    try {
      if (!body || body.jsonrpc !== "2.0" || !body.method) { res.status(400).json(jsonRpcError(id, -32600, "Invalid JSON-RPC request")); return; }
      if (body.method === "initialize") { res.setHeader("Mcp-Session-Id", `claucode-${Date.now()}`); res.json(jsonRpc(id, { protocolVersion: "2024-11-05", capabilities: { tools: {} }, serverInfo: { name: "ClauCode", version: "0.2.0" }, instructions: "Use workspace tools to create, edit, check and inspect persistent projects. build_apk never invents an artifact URL." })); return; }
      if (body.method === "notifications/initialized") { res.status(202).end(); return; }
      if (body.method === "ping") { res.json(jsonRpc(id, {})); return; }
      if (body.method === "tools/list") { res.json(jsonRpc(id, { tools })); return; }
      if (body.method === "tools/call") { const name = typeof body.params?.name === "string" ? body.params.name : ""; const args = (body.params?.arguments || {}) as Record<string, unknown>; try { res.json(jsonRpc(id, await callTool(name, args))); } catch (error) { res.json(jsonRpc(id, textResult(error instanceof Error ? error.message : "Tool failed", true))); } return; }
      res.status(400).json(jsonRpcError(id, -32601, `Method not found: ${body.method}`));
    } catch (error) { res.status(200).json(jsonRpcError(id, -32000, error instanceof Error ? error.message : "MCP request failed")); }
  });
}

import { execFile } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";
import path from "node:path";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);
const PROJECTS_ROOT = path.resolve(process.env.CLAUCODE_PROJECTS_DIR || path.join(process.cwd(), "data", "projects"));
const BUILDS_ROOT = path.join(PROJECTS_ROOT, ".builds");
const PROJECT_TYPES = ["html", "love2d", "godot", "android-web"] as const;
export type ProjectType = (typeof PROJECT_TYPES)[number];
const MAX_FILE_BYTES = 20 * 1024 * 1024;

export type ProjectManifest = {
  name: string;
  type: ProjectType;
  createdAt: string;
  updatedAt: string;
};

export type BuildRecord = {
  id: string;
  project: string;
  appName: string;
  packageId: string;
  status: "queued" | "running" | "completed" | "failed";
  startedAt: string;
  finishedAt?: string;
  log: string;
  apkPath?: string;
  error?: string;
};

function assertProjectName(name: string) {
  if (!/^[a-zA-Z][a-zA-Z0-9_-]{1,63}$/.test(name)) throw new Error("Invalid project name. Use 2–64 letters, numbers, _ or -.");
}

function assertRelativePath(filePath: string) {
  const normalized = filePath.replace(/\\/g, "/").replace(/^\/+/, "");
  if (!normalized || normalized.includes("\0") || normalized.split("/").some((part) => part === ".." || part === ".")) throw new Error("Invalid file path. Absolute paths and .. are not allowed.");
  return normalized;
}

function projectDir(project: string) {
  assertProjectName(project);
  return path.join(PROJECTS_ROOT, project);
}

function filePath(project: string, file: string) {
  const base = projectDir(project);
  const relative = assertRelativePath(file);
  const resolved = path.resolve(base, relative);
  if (resolved !== base && !resolved.startsWith(`${base}${path.sep}`)) throw new Error("File path escapes project root.");
  return { base, relative, resolved };
}

async function ensureRoots() {
  await fs.mkdir(PROJECTS_ROOT, { recursive: true });
  await fs.mkdir(BUILDS_ROOT, { recursive: true });
}

async function readManifest(project: string): Promise<ProjectManifest> {
  const raw = await fs.readFile(path.join(projectDir(project), ".claucode.json"), "utf8");
  return JSON.parse(raw) as ProjectManifest;
}

async function writeManifest(manifest: ProjectManifest) {
  await fs.writeFile(path.join(projectDir(manifest.name), ".claucode.json"), `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
}

export async function createProject(name: string, type: ProjectType) {
  await ensureRoots();
  assertProjectName(name);
  if (!PROJECT_TYPES.includes(type)) throw new Error(`Unsupported project type: ${type}`);
  const dir = projectDir(name);
  try {
    await fs.access(path.join(dir, ".claucode.json"));
    throw new Error(`Project already exists: ${name}`);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
  }
  await fs.mkdir(dir, { recursive: true });
  const now = new Date().toISOString();
  const manifest = { name, type, createdAt: now, updatedAt: now } satisfies ProjectManifest;
  await writeManifest(manifest);
  if (type === "html" || type === "android-web") {
    await writeFile(name, "index.html", "<!doctype html>\n<html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>ClauCode App</title></head><body><main id=\"app\"></main><script src=\"app.js\"></script></body></html>\n");
    await writeFile(name, "app.js", "document.querySelector('#app').textContent = 'ClauCode project ready';\n");
  }
  return { project: manifest, path: dir, files: await listFiles(name) };
}

export async function writeFile(project: string, file: string, content: string) {
  if (typeof content !== "string") throw new Error("content must be a string");
  const { base, relative, resolved } = filePath(project, file);
  if (Buffer.byteLength(content, "utf8") > MAX_FILE_BYTES) throw new Error(`File is too large. Maximum is ${MAX_FILE_BYTES} bytes.`);
  await fs.access(path.join(base, ".claucode.json"));
  await fs.mkdir(path.dirname(resolved), { recursive: true });
  const temp = `${resolved}.tmp-${randomUUID()}`;
  await fs.writeFile(temp, content, "utf8");
  await fs.rename(temp, resolved);
  const manifest = await readManifest(project);
  await writeManifest({ ...manifest, updatedAt: new Date().toISOString() });
  return { project, path: relative, bytes: Buffer.byteLength(content, "utf8"), sha256: createHash("sha256").update(content).digest("hex") };
}

export async function readFile(project: string, file: string) {
  const { relative, resolved } = filePath(project, file);
  const content = await fs.readFile(resolved, "utf8");
  return { project, path: relative, content, bytes: Buffer.byteLength(content, "utf8"), sha256: createHash("sha256").update(content).digest("hex") };
}

export async function editFile(project: string, file: string, oldText: string, newText: string) {
  if (!oldText) throw new Error("old must not be empty");
  const current = await readFile(project, file);
  const count = current.content.split(oldText).length - 1;
  if (count !== 1) throw new Error(`Expected exactly one match for old text, found ${count}.`);
  return writeFile(project, file, current.content.replace(oldText, newText));
}

export async function deleteFile(project: string, file: string) {
  const { base, relative, resolved } = filePath(project, file);
  if (relative === ".claucode.json") throw new Error("Cannot delete project manifest.");
  await fs.rm(resolved, { force: false });
  const manifest = await readManifest(project);
  await writeManifest({ ...manifest, updatedAt: new Date().toISOString() });
  await removeEmptyDirs(path.dirname(resolved), base);
  return { project, path: relative, deleted: true };
}

async function removeEmptyDirs(dir: string, stop: string): Promise<void> {
  if (dir === stop || !dir.startsWith(`${stop}${path.sep}`)) return;
  try { if ((await fs.readdir(dir)).length === 0) { await fs.rmdir(dir); await removeEmptyDirs(path.dirname(dir), stop); } } catch { /* best effort */ }
}

export async function listFiles(project: string) {
  const base = projectDir(project);
  await fs.access(path.join(base, ".claucode.json"));
  const result: Array<{ path: string; bytes: number }> = [];
  async function walk(dir: string) {
    for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
      if (entry.name === ".builds" || entry.name === "node_modules") continue;
      const absolute = path.join(dir, entry.name);
      if (entry.isDirectory()) await walk(absolute);
      else result.push({ path: path.relative(base, absolute).replace(/\\/g, "/"), bytes: (await fs.stat(absolute)).size });
    }
  }
  await walk(base);
  return result.sort((a, b) => a.path.localeCompare(b.path));
}

export async function runCheck(project: string) {
  const files = await listFiles(project);
  const logs: string[] = [`Checking ${project} (${files.length} files)`];
  const errors: string[] = [];
  for (const item of files) {
    const full = filePath(project, item.path).resolved;
    if (item.path.endsWith(".json")) {
      try { JSON.parse(await fs.readFile(full, "utf8")); logs.push(`OK json ${item.path}`); } catch (error) { errors.push(`${item.path}: ${(error as Error).message}`); }
    } else if (item.path.endsWith(".js") || item.path.endsWith(".mjs")) {
      try { await execFileAsync(process.execPath, ["--check", full], { timeout: 10000 }); logs.push(`OK syntax ${item.path}`); } catch (error) { errors.push(`${item.path}: ${(error as Error).message}`); }
    } else if (item.path.endsWith(".html")) {
      const html = await fs.readFile(full, "utf8");
      if (!html.toLowerCase().includes("<html") || !html.toLowerCase().includes("</html>")) errors.push(`${item.path}: missing html root`);
      else logs.push(`OK html ${item.path}`);
    }
  }
  if (errors.length) return { ok: false, project, errors, log: [...logs, ...errors].join("\n") };
  return { ok: true, project, errors: [], log: [...logs, "Check passed"].join("\n") };
}

function buildFile(buildId: string) { return path.join(BUILDS_ROOT, `${buildId}.json`); }
async function saveBuild(build: BuildRecord) { await ensureRoots(); await fs.writeFile(buildFile(build.id), `${JSON.stringify(build, null, 2)}\n`, "utf8"); }
async function loadBuild(buildId: string) { return JSON.parse(await fs.readFile(buildFile(buildId), "utf8")) as BuildRecord; }

export async function buildApk(project: string, appName: string, packageId: string, icon?: string) {
  assertProjectName(project);
  if (!/^[a-zA-Z][a-zA-Z0-9_.]{2,63}$/.test(packageId) || packageId.split(".").some((part) => !/^[a-zA-Z][a-zA-Z0-9_]*$/.test(part))) throw new Error("Invalid package_id. Use Android format like com.example.myapp.");
  const manifest = await readManifest(project);
  const build: BuildRecord = { id: `build-${Date.now()}-${randomUUID().slice(0, 8)}`, project, appName, packageId, status: "failed", startedAt: new Date().toISOString(), log: "" };
  await saveBuild(build);
  const logs = [`Build ${build.id}`, `Project: ${manifest.name} (${manifest.type})`, `App name: ${appName}`, `Package: ${packageId}`];
  const hasJava = Boolean(process.env.JAVA_HOME || process.platform === "linux") && await commandExists("java");
  const hasGradle = await commandExists("gradle");
  const hasAndroidSdk = Boolean(process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT);
  if (!hasJava || !hasGradle || !hasAndroidSdk) {
    const missing = [!hasJava && "Java", !hasGradle && "Gradle", !hasAndroidSdk && "ANDROID_HOME/ANDROID_SDK_ROOT"].filter(Boolean).join(", ");
    build.error = `Android build worker unavailable: missing ${missing}. HTML/WebView packaging requires a configured Android SDK and Gradle worker.`;
    build.log = [...logs, "FAILED", build.error, "No APK was created; no download URL is available."].join("\n");
    await saveBuild(build);
    return { ok: false, buildId: build.id, status: build.status, log: build.log, error: build.error };
  }
  build.error = "Android build execution is intentionally disabled in the sandbox; use the managed Android build worker.";
  build.log = [...logs, "FAILED", build.error].join("\n");
  await saveBuild(build);
  return { ok: false, buildId: build.id, status: build.status, log: build.log, error: build.error };
}

async function commandExists(command: string) {
  try { await execFileAsync("sh", ["-lc", `command -v ${command}`], { timeout: 2000 }); return true; } catch { return false; }
}

export async function getBuildStatus(buildId: string) { return loadBuild(buildId); }

export async function projectStatus() {
  await ensureRoots();
  const projects: Array<ProjectManifest & { files: number }> = [];
  for (const entry of await fs.readdir(PROJECTS_ROOT, { withFileTypes: true })) {
    if (!entry.isDirectory() || entry.name === ".builds") continue;
    try { const manifest = await readManifest(entry.name); projects.push({ ...manifest, files: (await listFiles(entry.name)).length }); } catch { /* skip invalid dirs */ }
  }
  return {
    server: "ready",
    storage: PROJECTS_ROOT,
    projects,
    tools: ["create_project", "write_file", "edit_file", "read_file", "list_files", "delete_file", "run_check", "build_apk", "get_build_status", "project_status"],
    android: { java: await commandExists("java"), gradle: await commandExists("gradle"), sdk: Boolean(process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT) },
  };
}

export { PROJECTS_ROOT, PROJECT_TYPES };

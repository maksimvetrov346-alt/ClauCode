import { z } from "zod";
import { invokeLLM } from "./_core/llm";
import type { Message, Tool } from "./_core/llm";
import { buildApk, createProject, deleteFile, editFile, getBuildStatus, listFiles, projectStatus, readFile, runCheck, writeFile } from "./_core/projectManager";
import { getSessionCookieName, getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

const chatMessageSchema = z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(12000) });
const normalizeMcpUrl = (value: string) => value.trim().replace(/\/$/, "");

const workspaceTools: Tool[] = [
  { type: "function", function: { name: "create_project", description: "Create a persistent project.", parameters: { type: "object", properties: { name: { type: "string" }, type: { type: "string", enum: ["html", "love2d", "godot", "android-web"] } }, required: ["name", "type"] } } },
  { type: "function", function: { name: "write_file", description: "Write a complete file.", parameters: { type: "object", properties: { project: { type: "string" }, path: { type: "string" }, content: { type: "string" } }, required: ["project", "path", "content"] } } },
  { type: "function", function: { name: "edit_file", description: "Replace exactly one occurrence in a file.", parameters: { type: "object", properties: { project: { type: "string" }, path: { type: "string" }, old: { type: "string" }, new: { type: "string" } }, required: ["project", "path", "old", "new"] } } },
  { type: "function", function: { name: "read_file", description: "Read a file.", parameters: { type: "object", properties: { project: { type: "string" }, path: { type: "string" } }, required: ["project", "path"] } } },
  { type: "function", function: { name: "list_files", description: "List project files.", parameters: { type: "object", properties: { project: { type: "string" } }, required: ["project"] } } },
  { type: "function", function: { name: "run_check", description: "Run syntax checks.", parameters: { type: "object", properties: { project: { type: "string" } }, required: ["project"] } } },
  { type: "function", function: { name: "build_apk", description: "Build APK if Android worker is available; never invent a URL.", parameters: { type: "object", properties: { project: { type: "string" }, app_name: { type: "string" }, package_id: { type: "string" } }, required: ["project", "app_name", "package_id"] } } },
  { type: "function", function: { name: "project_status", description: "Inspect projects and toolchain.", parameters: { type: "object", properties: {} } } },
];

async function executeWorkspaceTool(name: string, args: Record<string, unknown>) {
  switch (name) {
    case "create_project": return createProject(String(args.name || ""), args.type as "html" | "love2d" | "godot" | "android-web");
    case "write_file": return writeFile(String(args.project || ""), String(args.path || ""), String(args.content ?? ""));
    case "edit_file": return editFile(String(args.project || ""), String(args.path || ""), String(args.old ?? ""), String(args.new ?? ""));
    case "read_file": return readFile(String(args.project || ""), String(args.path || ""));
    case "list_files": return listFiles(String(args.project || ""));
    case "run_check": return runCheck(String(args.project || ""));
    case "build_apk": return buildApk(String(args.project || ""), String(args.app_name || ""), String(args.package_id || ""));
    case "project_status": return projectStatus();
    default: throw new Error(`Unknown workspace tool: ${name}`);
  }
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => { const cookieOptions = getSessionCookieOptions(ctx.req); ctx.res.clearCookie(getSessionCookieName(ctx.req), { ...cookieOptions, maxAge: -1 }); return { success: true } as const; }),
  }),
  assistant: router({
    chat: publicProcedure.input(z.object({ messages: z.array(chatMessageSchema).min(1).max(40), projectName: z.string().max(80).optional() })).mutation(async ({ input }) => {
      const messages: Message[] = [
        { role: "system", content: ["You are ClauCode, a focused coding and creative-build assistant.", "Answer in the user's language. Be practical, occasionally witty, and do not claim builds or file changes unless a tool result proves it.", `Current workspace: ${input.projectName || "claucode-app"}.`].join("\n") },
        ...input.messages,
      ];
      let result = await invokeLLM({ messages, tools: workspaceTools, toolChoice: "auto", maxTokens: 1400 });
      const executed: Array<{ name: string; result: unknown }> = [];
      for (let round = 0; round < 4; round += 1) {
        const assistant = result.choices?.[0]?.message;
        if (!assistant?.tool_calls?.length) break;
        messages.push({ role: "assistant", content: typeof assistant.content === "string" ? assistant.content : "", tool_calls: assistant.tool_calls });
        for (const call of assistant.tool_calls) {
          let toolResult: unknown;
          try { toolResult = await executeWorkspaceTool(call.function.name, JSON.parse(call.function.arguments || "{}")); }
          catch (error) { toolResult = { ok: false, error: error instanceof Error ? error.message : "Tool failed" }; }
          executed.push({ name: call.function.name, result: toolResult });
          messages.push({ role: "tool", tool_call_id: call.id, content: JSON.stringify(toolResult) });
        }
        result = await invokeLLM({ messages, tools: workspaceTools, toolChoice: "auto", maxTokens: 1400 });
      }
      const content = result.choices?.[0]?.message?.content;
      const reply = typeof content === "string" ? content.trim() : Array.isArray(content) ? content.filter((part): part is { type: "text"; text: string } => part.type === "text").map((part) => part.text).join("\n").trim() : "Не удалось получить текстовый ответ.";
      return { reply: reply || "Модель вернула пустой ответ. Попробуй переформулировать задачу.", model: result.model, executed };
    }),
  }),
  workspace: router({
    status: publicProcedure.query(() => projectStatus()),
    createProject: publicProcedure.input(z.object({ name: z.string(), type: z.enum(["html", "love2d", "godot", "android-web"]) })).mutation(({ input }) => createProject(input.name, input.type)),
    files: publicProcedure.input(z.object({ project: z.string() })).query(({ input }) => listFiles(input.project)),
    readFile: publicProcedure.input(z.object({ project: z.string(), path: z.string() })).query(({ input }) => readFile(input.project, input.path)),
    writeFile: publicProcedure.input(z.object({ project: z.string(), path: z.string(), content: z.string() })).mutation(({ input }) => writeFile(input.project, input.path, input.content)),
    editFile: publicProcedure.input(z.object({ project: z.string(), path: z.string(), old: z.string(), new: z.string() })).mutation(({ input }) => editFile(input.project, input.path, input.old, input.new)),
    deleteFile: publicProcedure.input(z.object({ project: z.string(), path: z.string() })).mutation(({ input }) => deleteFile(input.project, input.path)),
    runCheck: publicProcedure.input(z.object({ project: z.string() })).mutation(({ input }) => runCheck(input.project)),
    buildApk: publicProcedure.input(z.object({ project: z.string(), appName: z.string(), packageId: z.string(), icon: z.string().optional() })).mutation(({ input }) => buildApk(input.project, input.appName, input.packageId, input.icon)),
    buildStatus: publicProcedure.input(z.object({ buildId: z.string() })).query(({ input }) => getBuildStatus(input.buildId)),
  }),
  mcp: router({
    connect: publicProcedure.input(z.object({ url: z.string().url().refine((value) => value.startsWith("https://") || value.startsWith("http://localhost"), "MCP endpoint должен использовать HTTPS (или localhost для разработки)."), name: z.string().trim().min(1).max(60).optional() })).mutation(async ({ input }) => {
      const url = normalizeMcpUrl(input.url); const controller = new AbortController(); const timeout = setTimeout(() => controller.abort(), 7000);
      try {
        const response = await fetch(url, { method: "POST", headers: { accept: "application/json, text/event-stream", "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: `claucode-${Date.now()}`, method: "initialize", params: { protocolVersion: "2024-11-05", capabilities: {}, clientInfo: { name: "ClauCode", version: "0.2.0" } } }), signal: controller.signal });
        const raw = await response.text(); if (!response.ok) return { connected: false, url, name: input.name || new URL(url).hostname, status: "error" as const, message: `Сервер ответил HTTP ${response.status}.` };
        let serverName = input.name || new URL(url).hostname; try { serverName = (JSON.parse(raw) as { result?: { serverInfo?: { name?: string } } }).result?.serverInfo?.name || serverName; } catch { /* SSE or non-JSON */ }
        return { connected: true, url, name: serverName, status: "connected" as const, message: "MCP initialize завершён. Endpoint отвечает." };
      } catch (error) { return { connected: false, url, name: input.name || url, status: "error" as const, message: error instanceof Error && error.name === "AbortError" ? "Превышено время ожидания ответа MCP." : "Не удалось связаться с endpoint." }; }
      finally { clearTimeout(timeout); }
    }),
  }),
});

export type AppRouter = typeof appRouter;

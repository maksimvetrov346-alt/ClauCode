document.querySelector('#app').textContent = 'ClauCode project ready';

export type ChatRole = "user" | "assistant";

export type ChatMessage = {
  id: string;
  role: ChatRole;
  content: string;
  time?: string;
};

export type McpConnection = {
  id: string;
  name: string;
  url: string;
  status: "connected" | "error" | "checking";
  message?: string;
};

export const QUICK_PROMPTS = [
  { label: "Собрать APK", prompt: "Разложи по шагам, как собрать Android APK для моего проекта." },
  { label: "Игра 3D", prompt: "Спроектируй MVP 3D-игры и предложи структуру файлов и сцены." },
  { label: "Текстура", prompt: "Создай пайплайн для рисования и подключения текстур к игровому ассету." },
];

export const STARTER_MESSAGES: ChatMessage[] = [
  {
    id: "welcome",
    role: "assistant",
    content:
      "Привет, я ClauCode. Опиши, что нужно собрать — APK, файл, игру, текстуру или MCP-связку. Я разложу задачу по шагам и отмечу, какие инструменты понадобятся.",
    time: "сейчас",
  },
];
